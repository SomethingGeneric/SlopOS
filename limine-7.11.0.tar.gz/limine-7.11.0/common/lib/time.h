#ifndef LIB__TIME_H__
#define LIB__TIME_H__

#include <stdint.h>

uint64_t time(void);

#endif
