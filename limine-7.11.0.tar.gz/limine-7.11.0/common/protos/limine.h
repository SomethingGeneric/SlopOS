#ifndef PROTOS__LIMINE_H__
#define PROTOS__LIMINE_H__

#include <stdnoreturn.h>

noreturn void limine_load(char *config, char *cmdline);

#endif
